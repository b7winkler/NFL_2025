offense_raw <- read.csv("/Users/gabegutz/Desktop/NFL PROJECT/NFL_2025_offense_raw.csv",
                        stringsAsFactors = FALSE)

View(offense_raw)

defense_raw <- read.csv("/Users/gabegutz/Desktop/NFL PROJECT/NFL_2025_defense_raw.csv",
                        stringsAsFactors = FALSE)

View(defense_raw)        # to see it like a spreadsheet
names(defense_raw)       # to see the column names
head(defense_raw)        # to see the first few rows
